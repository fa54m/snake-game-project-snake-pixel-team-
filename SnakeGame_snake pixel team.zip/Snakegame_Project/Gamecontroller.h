#ifndef GAMECONTROLLER_H
#define GAMECONTROLLER_H
#include <windows.h>
#include <fstream>
#include <iostream>
#include "gotoxy.h"
enum BorderColor {
    BLUE = 9,
    RED = 12
};
class Gamecontroller {
public:
    void drawborder() {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), BLUE);
        for (int i = 0; i < 40; i++) {
            gotoxy(i, 0); std::cout << '#';
            gotoxy(i, 20); std::cout << '#';
        }
        for (int i = 0; i < 20; i++) {
            gotoxy(0, i); std::cout << '#';
            gotoxy(40, i); std::cout << '#'; }
    }
    void drawscore(int score, int speed) {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), RED);
        gotoxy(1, 21);
        std::cout << "Score: " << score << "  ";
        gotoxy(20, 21);
        std::cout << "Speed: " << (200 - speed) << "  ";}
    int loadhighscore() {
        std::ifstream file("highscore.txt");
        int highScore = 0;
        if (file >> highScore) return highScore;
        return 0;
    }
    void savehighscore(int score) {
        std::ofstream file("highscore.txt");
        if (file) file << score;  }
};

#endif
