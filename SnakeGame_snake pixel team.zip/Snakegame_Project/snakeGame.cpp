#include <windows.h>
#include <conio.h>
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "gotoxy.h"
#include "Position.h"
#include "Food.h"
#include "Snake.h"
#include "Gamecontroller.h"
using namespace std;
int main() {
    srand(time(NULL));
    system("title Snake Game");
    system("mode con: cols=42 lines=23");
    CONSOLE_CURSOR_INFO cursorInfo;
    cursorInfo.dwSize = 100;
    cursorInfo.bVisible = false;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursorInfo);
    int mapChoice;
    do {
        cout << "Choose the mode :\n1 - With Walls \n2 - Without Walls  \n>> ";
        cin >> mapChoice;
        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
        }
        if (mapChoice != 1 && mapChoice != 2) {
            system("cls");
     }
    } while (mapChoice != 1 && mapChoice != 2);
    system("cls");
    Snake snake;
    Food food;
    Gamecontroller g_control;
    int score = 0;
    int speed = 200;
    int highScore = g_control.loadhighscore();
    bool paused = false;
    bool gameOver = false;
    while (!gameOver) {
        system("cls");
        g_control.drawborder();
        food.draw();
        snake.draw();
        g_control.drawscore(score, speed);
        gotoxy(1, 22);
        cout << "Map: " << (mapChoice == 1 ? "Walls Kill" : "Walls Pass");
        if (paused) {
            gotoxy(15, 10);
            SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), RED);
            cout << "PAUSED";
        }
       if (_kbhit()) {
            char key = _getch();
            switch (tolower(key)) {
                case 'w': snake.changedirection(0); break;
                case 'd': snake.changedirection(1); break;
                case 's': snake.changedirection(2); break;
                case 'a': snake.changedirection(3); break;
                case ' ': paused = !paused; break;
                case 27: gameOver = true; break;           }
 }
        if (!paused) {
            snake.move();
            Position head = snake.gethead();
            if (mapChoice == 1) {
                if (head.x <= 0 || head.x >= 40 || head.y <= 0 || head.y >= 20) {
                    gameOver = true; }
            } else {
                if (head.x <= 0) head.x = 39;
                else if (head.x >= 40) head.x = 1;
                if (head.y <= 0) head.y = 19;
                else if (head.y >= 20) head.y = 1;
                snake.sethead(head);}
            if (snake.checkselfcollision()) {
                gameOver = true;
            }
            if (head.x == food.getposition().x && head.y == food.getposition().y) {
                snake.setgrow(true);
                food.generate();
                score += 10;
                if (speed > 50) speed -= 5;} }

  Sleep(speed);
 }
    system("cls");
    gotoxy(15, 10);
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), RED);
    if (score > highScore) {
        g_control.savehighscore(score);
        highScore = score; }
    gotoxy(16, 10);
    cout << "GAME OVER!";
    gotoxy(14, 11);
    cout << "Final Score: " << score;
    gotoxy(13, 12);
    cout << "High score : " << highScore;
    gotoxy(9, 13);
    cout << "Press any key to exit...";
    _getch();
    return 0;
}
