#ifndef SNAKE_H
#define SNAKE_H
#include <windows.h>
#include <iostream>
#include <vector>
#include "Position.h"
#include "gotoxy.h"
enum SnakeColor {
    WHITE = 15
};
class Snake {
private:
    std::vector<Position> body;
    int direction;
    const char symbol = 'o';
    bool grow;
public:
    Snake() {
        body.push_back(Position(20, 10));
        direction = 1;
        grow = false;}
    void changedirection(int newDir) {
        if ((direction == 0 && newDir == 2) ||
            (direction == 2 && newDir == 0) ||
            (direction == 1 && newDir == 3) ||
            (direction == 3 && newDir == 1)) {
            return;
        }
        direction = newDir;}
    void move() {
        Position tail = body.back();
        for (int i = body.size() - 1; i > 0; i--) {
            body[i] = body[i - 1];
        }
        switch (direction) {
            case 0: body[0].y--; break;
            case 1: body[0].x++; break;
            case 2: body[0].y++; break;
            case 3: body[0].x--; break;}
        if (grow) {
            body.push_back(tail);
            grow = false;}}
    void setgrow(bool g) { grow = g; }
    Position gethead() const { return body[0]; }
    void sethead(Position newHead) {
        if (!body.empty()) {
            body[0] = newHead;
        }
    }
    std::vector<Position> getbody() const { return body; }
    bool checkselfcollision() const {
        for (int i = 1; i < body.size(); i++) {
            if (body[0].x == body[i].x && body[0].y == body[i].y) {
                return true;
            }
}
        return false;}
    void draw() const {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), WHITE);
        for (const Position& p : body) {
            gotoxy(p.x, p.y);
            std::cout << symbol;        }
       }
};

#endif
