#ifndef FOOD_H
#define FOOD_H
#include <windows.h>
#include <iostream>
#include <cstdlib>
#include "Position.h"
#include "gotoxy.h"
enum Color {
    GREEN = 10
};
class Food {
private:
    Position pos;
    const char symbol = 'x';
public:
    Food() { generate(); }
    void generate() {
        pos.x = rand() % 38 + 1;
        pos.y = rand() % 18 + 1;
    }
    Position getposition() const { return pos; }
    void draw() const {
        SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), GREEN);
        gotoxy(pos.x, pos.y);
        std::cout << symbol;
    }
};
#endif
